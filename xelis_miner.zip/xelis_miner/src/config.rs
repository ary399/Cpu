// daemon address by default when no specified
pub const DEFAULT_DAEMON_ADDRESS: &str = "stratum+tcp://sg.vipor.net:5077";